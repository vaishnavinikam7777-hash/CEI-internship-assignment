"""
Quick smoke test: ingests the sample notes and asks a few questions
non-interactively, so the whole pipeline can be verified in one run.
"""
from src.rag_pipeline import RAGPipeline

QUESTIONS = [
    "What is RAG and why does it matter?",
    "What are the core components of a RAG system?",
    "What chunk size is used in the chunking strategy?",
    "What is the capital of France?",  # not in the document -> tests grounding
]


def main():
    pipeline = RAGPipeline()
    pipeline.ingest("data/sample_notes.txt")

    for q in QUESTIONS:
        print(f"\nQ: {q}")
        answer = pipeline.ask(q, top_k=3, show_sources=True)
        print(f"A: {answer}")


if __name__ == "__main__":
    main()
