# Document Question Answering System (RAG)

A Retrieval-Augmented Generation system that answers questions grounded in
your own documents (PDF or text) instead of relying only on a language
model's internal, frozen knowledge.

## Architecture

```
PDF/TXT file
    │
    ▼
1. Document Ingestion   (src/ingest.py)
    │
    ▼
2. Text Chunking        (src/ingest.py)   -> overlapping ~500-word chunks
    │
    ▼
3. Embedding Creation    (src/vector_store.py) -> all-MiniLM-L6-v2
    │
    ▼
4. Vector Database       (src/vector_store.py) -> FAISS IndexFlatIP
    │
    ▼
5. Query Processing  <───  user question
    │
    ▼
6. Context Retrieval     (top-k similarity search)
    │
    ▼
7. Answer Generation     (src/generate.py)  -> google/flan-t5-base
    │
    ▼
Grounded answer
```

## Components

| Stage | Tool used |
|---|---|
| Embedding model | `sentence-transformers/all-MiniLM-L6-v2` |
| Vector store | FAISS (`IndexFlatIP`, cosine similarity) |
| Generator LLM | `google/flan-t5-base` (instruction-tuned, runs on CPU) |
| PDF parsing | `pypdf` |

## Setup

```bash
pip install -r requirements.txt
```

First run will download the embedding model (~90MB) and flan-t5-base
(~950MB) from Hugging Face — this requires an internet connection.

## Usage

Interactive CLI — ask questions about any document:

```bash
python main.py data/sample_notes.txt
python main.py path/to/your_resume.pdf
```

```
Q: What are the core components of a RAG system?
A: embedding model, vector database, retriever, generator
```

Non-interactive smoke test (ingests the sample notes and runs a few
built-in questions, printing retrieved sources for each):

```bash
python test_pipeline.py
```

## Project structure

```
rag-project/
├── main.py              # CLI entry point
├── test_pipeline.py      # scripted smoke test
├── requirements.txt
├── data/
│   └── sample_notes.txt  # example document to test on
└── src/
    ├── ingest.py          # Stage 1-2: load + chunk documents
    ├── vector_store.py    # Stage 3-4: embed + FAISS index/search
    ├── generate.py        # Stage 7: grounded answer generation
    └── rag_pipeline.py     # orchestrates the full pipeline
```

## Design choices / experiments to try next

- **Chunking**: currently fixed-size word chunks with overlap; a
  sentence-aware or semantic chunker could improve retrieval accuracy.
- **Hybrid search**: combine BM25 keyword search with vector search.
- **Re-ranking**: add a cross-encoder re-ranker on top of the FAISS
  top-k results before generation.
- **Swap the generator**: any Hugging Face `text2text-generation` or
  `text-generation` model can be dropped in via `AnswerGenerator(model_name=...)`.

## Key learnings

- How retrieval and generation combine to ground LLM answers in real data
- Working with sentence embeddings and FAISS similarity search
- Chunking strategy trade-offs (chunk size vs. context preservation)
- Building a modular, swappable RAG pipeline (embedder / store / generator
  are all independently replaceable)
