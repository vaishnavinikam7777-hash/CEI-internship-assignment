"""
Stage 3 & 4: Embedding Creation + Vector Database
Converts text chunks to vectors and stores them in a FAISS index
for fast similarity search.
"""
import pickle
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer


class VectorStore:
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        self.embedder = SentenceTransformer(model_name)
        self.index = None
        self.chunks: list[str] = []

    def build(self, chunks: list[str]):
        """Embed chunks and build a FAISS index (cosine similarity via normalized vectors)."""
        self.chunks = chunks
        embeddings = self.embedder.encode(chunks, convert_to_numpy=True, show_progress_bar=False)
        faiss.normalize_L2(embeddings)

        dim = embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dim)  # inner product on normalized vecs = cosine sim
        self.index.add(embeddings)

    def search(self, query: str, top_k: int = 3) -> list[tuple[str, float]]:
        """Embed the query and retrieve the top_k most similar chunks."""
        q_emb = self.embedder.encode([query], convert_to_numpy=True)
        faiss.normalize_L2(q_emb)

        scores, indices = self.index.search(q_emb, top_k)
        results = [
            (self.chunks[i], float(scores[0][rank]))
            for rank, i in enumerate(indices[0]) if i != -1
        ]
        return results

    def save(self, path_prefix: str):
        faiss.write_index(self.index, f"{path_prefix}.index")
        with open(f"{path_prefix}_chunks.pkl", "wb") as f:
            pickle.dump(self.chunks, f)

    def load(self, path_prefix: str):
        self.index = faiss.read_index(f"{path_prefix}.index")
        with open(f"{path_prefix}_chunks.pkl", "rb") as f:
            self.chunks = pickle.load(f)
