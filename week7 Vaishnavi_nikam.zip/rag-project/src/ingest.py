"""
Stage 1 & 2: Document Ingestion + Text Chunking
Loads PDFs/text files and splits them into overlapping chunks.
"""
import os
from pypdf import PdfReader


def load_document(path: str) -> str:
    """Load a PDF or .txt file and return raw text."""
    ext = os.path.splitext(path)[1].lower()

    if ext == ".pdf":
        reader = PdfReader(path)
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
    elif ext in (".txt", ".md"):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
    else:
        raise ValueError(f"Unsupported file type: {ext}")

    return text


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> list[str]:
    """
    Split text into overlapping word-based chunks.
    chunk_size: number of words per chunk
    overlap: number of words shared between consecutive chunks
    """
    words = text.split()
    if not words:
        return []

    chunks = []
    start = 0
    while start < len(words):
        end = start + chunk_size
        chunk = " ".join(words[start:end])
        chunks.append(chunk)
        if end >= len(words):
            break
        start = end - overlap  # step forward, keeping overlap

    return chunks


def load_and_chunk(path: str, chunk_size: int = 500, overlap: int = 50) -> list[str]:
    text = load_document(path)
    return chunk_text(text, chunk_size, overlap)
