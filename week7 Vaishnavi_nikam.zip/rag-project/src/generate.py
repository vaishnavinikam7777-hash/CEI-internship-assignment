"""
Stage 7: Answer Generation
Uses a small instruction-tuned LLM (FLAN-T5) to generate an answer
grounded in the retrieved context chunks.
"""
from transformers import pipeline


class AnswerGenerator:
    def __init__(self, model_name: str = "google/flan-t5-base"):
        self.pipe = pipeline("text2text-generation", model=model_name)

    def generate(self, question: str, context_chunks: list[str]) -> str:
        context = "\n\n".join(context_chunks)
        prompt = (
            "Answer the question using ONLY the context below. "
            "If the answer isn't in the context, say you don't know.\n\n"
            f"Context:\n{context}\n\n"
            f"Question: {question}\n"
            "Answer:"
        )
        result = self.pipe(prompt, max_new_tokens=200, do_sample=False)
        return result[0]["generated_text"].strip()
