"""
RAG Pipeline — ties together Stages 1-7:
Ingestion -> Chunking -> Embedding -> Vector DB -> Query -> Retrieval -> Generation
"""
from src.ingest import load_and_chunk
from src.vector_store import VectorStore
from src.generate import AnswerGenerator


class RAGPipeline:
    def __init__(self, embed_model="all-MiniLM-L6-v2", gen_model="google/flan-t5-base"):
        self.store = VectorStore(embed_model)
        self.generator = AnswerGenerator(gen_model)
        self._built = False

    def ingest(self, filepath: str, chunk_size: int = 500, overlap: int = 50):
        """Stages 1-4: load doc, chunk it, embed chunks, build vector index."""
        chunks = load_and_chunk(filepath, chunk_size, overlap)
        if not chunks:
            raise ValueError("No text extracted from document.")
        self.store.build(chunks)
        self._built = True
        print(f"Ingested '{filepath}' -> {len(chunks)} chunks indexed.")

    def ask(self, question: str, top_k: int = 3, show_sources: bool = False) -> str:
        """Stages 5-7: embed query, retrieve relevant chunks, generate answer."""
        if not self._built:
            raise RuntimeError("No document ingested yet. Call .ingest() first.")

        results = self.store.search(question, top_k=top_k)
        context_chunks = [chunk for chunk, score in results]
        answer = self.generator.generate(question, context_chunks)

        if show_sources:
            print("\n--- Retrieved context ---")
            for i, (chunk, score) in enumerate(results, 1):
                print(f"[{i}] (score={score:.3f}) {chunk[:150]}...")
            print("--------------------------\n")

        return answer
