"""
Document Question Answering System (RAG)
Entry point: ingest a document, then ask questions about it interactively.

Usage:
    python main.py path/to/document.pdf
    python main.py path/to/notes.txt
"""
import sys
from src.rag_pipeline import RAGPipeline


def main():
    if len(sys.argv) < 2:
        print("Usage: python main.py <path_to_document>")
        sys.exit(1)

    filepath = sys.argv[1]

    print("Loading models and building index... (first run downloads models, may take a minute)")
    pipeline = RAGPipeline()
    pipeline.ingest(filepath)

    print("\nDocument ready. Ask questions about it (type 'exit' to quit).\n")
    while True:
        question = input("Q: ").strip()
        if question.lower() in ("exit", "quit"):
            break
        if not question:
            continue
        answer = pipeline.ask(question, top_k=3, show_sources=True)
        print(f"A: {answer}\n")


if __name__ == "__main__":
    main()
