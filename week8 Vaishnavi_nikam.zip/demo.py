"""
demo.py
-------
Runs a handful of queries through the agent pipeline and prints:
  - the final result
  - the full trajectory (Q9)
  - batch-level completion rate + cost metrics (Q10)

Run with:  python demo.py
"""

import json

from agent_pipeline import batch_metrics, evaluate_trajectory, run_agent

QUERIES = [
    "calculate 12 * (3 + 4)",
    "please extract keywords about agent pipelines and tool routing",
    "run a parallel lookup for agent orchestration",
    "what is the weather like today",           # -> general route
    "calculate 10 / 0",                          # -> triggers a real error
]


def main():
    states = []
    for q in QUERIES:
        print(f"\n=== Query: {q!r} ===")
        # fail_probability > 0 on one run to demonstrate the retry loop
        fail_prob = 0.6 if "keywords" in q else 0.0
        state = run_agent(q, fail_probability=fail_prob)
        states.append(state)

        report = evaluate_trajectory(state)
        print("Result:", state.result)
        print("Trajectory report:")
        print(json.dumps(report, indent=2))

    print("\n=== Batch metrics across all runs ===")
    print(json.dumps(batch_metrics(states), indent=2))


if __name__ == "__main__":
    main()
