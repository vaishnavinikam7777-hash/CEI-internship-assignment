"""
agent_pipeline.py
------------------
A small single-agent pipeline implemented as a STATEFUL DIRECTED GRAPH (Q1).

Unlike a simple linear pipeline, this graph:
  - carries a shared `state` dict that every node can read/write (statefulness)
  - has edges chosen at runtime by conditional routing (Q3), not fixed in advance
  - supports a retry loop / cycle (Q4) when a tool call fails
  - logs every step into a trajectory for evaluation (Q9)
  - tracks task completion + cost metrics (Q10)

It intentionally avoids any heavyweight framework so it's easy to read and
runs anywhere with just Python + jsonschema installed.
"""

from __future__ import annotations

import concurrent.futures
import time
from dataclasses import dataclass, field
from typing import Callable

from jsonschema import ValidationError

from tools import (
    ToolError,
    calculator_tool,
    general_response_tool,
    keyword_extraction_tool,
    slow_lookup_tool,
)


# ---------------------------------------------------------------------------
# Graph primitives: Nodes + Edges (Q2)
# ---------------------------------------------------------------------------

@dataclass
class Node:
    """A single step in the workflow (e.g. 'Calculator Tool', 'Analyze Query').
    A node is just a name + a function that takes/returns the shared state.
    """
    name: str
    fn: Callable[[dict], dict]


@dataclass
class TrajectoryStep:
    node: str
    input_snapshot: dict
    output_snapshot: dict
    success: bool
    duration_s: float
    attempt: int = 1
    note: str = ""


@dataclass
class AgentState:
    """The state that flows through the graph (what makes it 'stateful')."""
    query: str
    history: list = field(default_factory=list)          # trajectory (Q9)
    result: dict | None = None
    tool_calls_made: int = 0                              # cost metric (Q10)
    total_time_s: float = 0.0                              # cost metric (Q10)
    completed: bool = False


# ---------------------------------------------------------------------------
# Node 1: Analyze query -> decide route  (Q3: conditional routing)
# ---------------------------------------------------------------------------

def analyze_query(query: str) -> str:
    """Rule-based routing logic for three query types (Q3)."""
    q = query.lower()
    if "calculate" in q or any(op in q for op in ["+", "-", "*", "/"]):
        return "calculator"
    if "keyword" in q or "extract" in q:
        return "keywords"
    if "lookup" in q and "parallel" in q:
        return "parallel_demo"
    return "general"


# ---------------------------------------------------------------------------
# Retry wrapper (Q4: cycles/loops for reliability)
# ---------------------------------------------------------------------------

def call_tool_with_retry(
    tool_fn: Callable[..., dict],
    payload: dict,
    node_name: str,
    state: AgentState,
    max_attempts: int = 3,
    fail_probability: float = 0.0,
) -> dict:
    """Calls a tool, retrying on ToolError up to max_attempts times.
    This is the 'cycle' in the directed graph: on failure we loop back
    to the same node instead of dead-ending the pipeline (Q4, Q8).
    """
    last_error = None
    for attempt in range(1, max_attempts + 1):
        start = time.perf_counter()
        try:
            output = tool_fn(payload, fail_probability=fail_probability)
            duration = time.perf_counter() - start
            state.tool_calls_made += 1
            state.total_time_s += duration
            state.history.append(
                TrajectoryStep(
                    node=node_name,
                    input_snapshot=payload,
                    output_snapshot=output,
                    success=True,
                    duration_s=duration,
                    attempt=attempt,
                )
            )
            return output
        except (ToolError, ValidationError) as exc:
            duration = time.perf_counter() - start
            state.tool_calls_made += 1
            state.total_time_s += duration
            last_error = exc
            state.history.append(
                TrajectoryStep(
                    node=node_name,
                    input_snapshot=payload,
                    output_snapshot={},
                    success=False,
                    duration_s=duration,
                    attempt=attempt,
                    note=f"error: {exc}",
                )
            )
    # All attempts exhausted -> error handling strategy #2: return a safe
    # fallback instead of crashing the whole pipeline (Q8).
    return {"error": str(last_error), "node": node_name}


# ---------------------------------------------------------------------------
# Parallel tool calls demo (Q7)
# ---------------------------------------------------------------------------

def run_tools_in_parallel(query: str, state: AgentState) -> dict:
    """Runs two independent tools (keyword extraction + slow lookup)
    concurrently since neither depends on the other's output (Q7).
    """
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        fut_keywords = pool.submit(
            call_tool_with_retry,
            keyword_extraction_tool, {"text": query}, "Keyword Extraction Tool", state,
        )
        fut_lookup = pool.submit(
            call_tool_with_retry,
            slow_lookup_tool, {"text": query}, "Slow Lookup Tool", state,
        )
        keywords_result = fut_keywords.result()
        lookup_result = fut_lookup.result()
    return {"keywords": keywords_result, "lookup": lookup_result}


# ---------------------------------------------------------------------------
# The graph runner
# ---------------------------------------------------------------------------

def run_agent(query: str, fail_probability: float = 0.0) -> AgentState:
    """Executes the stateful directed graph for a single query."""
    state = AgentState(query=query)

    route = analyze_query(query)
    state.history.append(
        TrajectoryStep(
            node="Analyze Query",
            input_snapshot={"query": query},
            output_snapshot={"route": route},
            success=True,
            duration_s=0.0,
        )
    )

    if route == "calculator":
        # Extract a naive expression: strip the word 'calculate'
        expr = query.lower().replace("calculate", "").strip()
        output = call_tool_with_retry(
            calculator_tool, {"expression": expr}, "Calculator Tool", state,
            fail_probability=fail_probability,
        )
    elif route == "keywords":
        output = call_tool_with_retry(
            keyword_extraction_tool, {"text": query}, "Keyword Extraction Tool", state,
            fail_probability=fail_probability,
        )
    elif route == "parallel_demo":
        output = run_tools_in_parallel(query, state)
    else:
        output = call_tool_with_retry(
            general_response_tool, {"text": query}, "General Response", state,
            fail_probability=fail_probability,
        )

    state.result = output
    state.completed = "error" not in output
    return state


# ---------------------------------------------------------------------------
# Trajectory + cost evaluation (Q9, Q10)
# ---------------------------------------------------------------------------

def evaluate_trajectory(state: AgentState) -> dict:
    """Looks beyond the final output at the whole sequence of steps (Q9)
    and computes task completion / cost metrics (Q10).
    """
    failed_steps = [s for s in state.history if not s.success]
    return {
        "query": state.query,
        "completed": state.completed,
        "num_steps": len(state.history),
        "num_failed_attempts": len(failed_steps),
        "tool_calls_made": state.tool_calls_made,
        "total_time_s": round(state.total_time_s, 4),
        "trajectory": [
            {
                "node": s.node,
                "attempt": s.attempt,
                "success": s.success,
                "duration_s": round(s.duration_s, 4),
                "note": s.note,
            }
            for s in state.history
        ],
    }


def batch_metrics(states: list[AgentState]) -> dict:
    """Task completion rate + average cost across many runs (Q10)."""
    n = len(states)
    completed = sum(1 for s in states if s.completed)
    total_calls = sum(s.tool_calls_made for s in states)
    total_time = sum(s.total_time_s for s in states)
    return {
        "runs": n,
        "task_completion_rate": round(completed / n, 3) if n else 0.0,
        "avg_tool_calls_per_run": round(total_calls / n, 2) if n else 0.0,
        "avg_time_s_per_run": round(total_time / n, 4) if n else 0.0,
    }
