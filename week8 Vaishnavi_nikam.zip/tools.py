"""
tools.py
--------
Individual tools the agent can call. Each tool declares a JSON Schema for its
input and output so calls can be validated before/after execution (Q6 - JSON
schema tools).

Every tool can be told to fail on purpose (for testing the retry loop, Q4/Q8).
"""

import random
import re
import time

from jsonschema import validate, ValidationError


# ---------------------------------------------------------------------------
# JSON Schemas (Q6: structuring tool inputs/outputs)
# ---------------------------------------------------------------------------

CALCULATOR_INPUT_SCHEMA = {
    "type": "object",
    "properties": {"expression": {"type": "string"}},
    "required": ["expression"],
}

CALCULATOR_OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "result": {"type": "number"},
        "expression": {"type": "string"},
    },
    "required": ["result", "expression"],
}

KEYWORD_INPUT_SCHEMA = {
    "type": "object",
    "properties": {"text": {"type": "string"}},
    "required": ["text"],
}

KEYWORD_OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "keywords": {"type": "array", "items": {"type": "string"}}
    },
    "required": ["keywords"],
}


class ToolError(Exception):
    """Raised when a tool fails to execute (used to trigger retry loop)."""


def _simulate_flaky_failure(fail_probability: float) -> None:
    """Randomly raise ToolError to simulate a transient failure (Q4, Q8)."""
    if random.random() < fail_probability:
        raise ToolError("Transient failure: simulated network/API glitch")


def calculator_tool(payload: dict, fail_probability: float = 0.0) -> dict:
    """Evaluates a basic arithmetic expression. Node: 'Calculator Tool'."""
    validate(instance=payload, schema=CALCULATOR_INPUT_SCHEMA)

    _simulate_flaky_failure(fail_probability)

    expression = payload["expression"]
    # Only allow digits, operators, parentheses, decimal points, spaces.
    if not re.fullmatch(r"[0-9+\-*/(). ]+", expression):
        raise ToolError(f"Unsafe or invalid expression: {expression!r}")

    try:
        result = eval(expression, {"__builtins__": {}}, {})  # noqa: S307 (sandboxed)
    except Exception as exc:
        raise ToolError(f"Could not evaluate expression: {exc}") from exc

    output = {"result": float(result), "expression": expression}
    validate(instance=output, schema=CALCULATOR_OUTPUT_SCHEMA)
    return output


def keyword_extraction_tool(payload: dict, fail_probability: float = 0.0) -> dict:
    """Extracts simple keywords (naive: words > 4 chars, deduplicated)."""
    validate(instance=payload, schema=KEYWORD_INPUT_SCHEMA)

    _simulate_flaky_failure(fail_probability)

    text = payload["text"]
    words = re.findall(r"[a-zA-Z]+", text.lower())
    stopwords = {"about", "these", "which", "there", "their", "would", "could"}
    keywords = sorted({w for w in words if len(w) > 4 and w not in stopwords})

    output = {"keywords": keywords}
    validate(instance=output, schema=KEYWORD_OUTPUT_SCHEMA)
    return output


def general_response_tool(payload: dict, fail_probability: float = 0.0) -> dict:
    """Fallback tool for queries that don't match a specific intent."""
    _simulate_flaky_failure(fail_probability)
    text = payload.get("text", "")
    return {"response": f"I received your query: {text!r}. No specialised tool matched it."}


def slow_lookup_tool(payload: dict, fail_probability: float = 0.0) -> dict:
    """A second 'independent' tool used to demonstrate parallel calls (Q7).
    Simulates latency (e.g. a network call) with time.sleep.
    """
    _simulate_flaky_failure(fail_probability)
    time.sleep(0.5)
    return {"lookup": f"metadata-for-{payload.get('text', '')[:10]}"}
