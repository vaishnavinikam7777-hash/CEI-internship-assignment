# Agentic AI Pipeline — Week 8 (Celebal CSI Internship)

A small single-agent pipeline built as a **stateful directed graph**, demonstrating
routing, tool use, retries, parallel calls, and trajectory evaluation.

## Files
- `tools.py` — individual tools (Calculator, Keyword Extraction, General Response,
  Slow Lookup), each with a JSON Schema for input/output validation.
- `agent_pipeline.py` — the graph engine: state object, conditional routing,
  retry loop, parallel tool execution, trajectory logging, and metrics.
- `demo.py` — runs 5 sample queries through the pipeline and prints results.
- `quiz_answers.md` — written answers to the Week 8 quiz.

## How to run
```bash
pip install jsonschema
python demo.py
```

## Concept → code map

| Quiz concept | Where it lives |
|---|---|
| Stateful directed graph | `AgentState` dataclass carried through every node in `agent_pipeline.py` |
| Nodes & edges | `Node` dataclass + the `if/elif` routing block in `run_agent()` |
| Conditional routing | `analyze_query()` — routes to calculator / keywords / parallel / general |
| Cycles / retry loop | `call_tool_with_retry()` — retries up to 3x on `ToolError` |
| JSON schema tools | schemas + `jsonschema.validate()` calls in `tools.py` |
| Sequential vs parallel calls | `run_tools_in_parallel()` uses `ThreadPoolExecutor` for independent tool calls |
| Error handling | try/except in `call_tool_with_retry`, safe fallback `{"error": ...}` output |
| Trajectory evaluation | `TrajectoryStep` list on `AgentState`, summarized by `evaluate_trajectory()` |
| Task completion rate & cost metrics | `batch_metrics()` — completion rate, avg tool calls, avg time per run |

## Example output
Running `python demo.py` shows, per query: the routed tool, the result, the
full step-by-step trajectory (including any failed retry attempts), and
batch-level metrics such as task completion rate across all sample runs.
