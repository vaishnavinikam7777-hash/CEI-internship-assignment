# Single Agent Systems & Agent Pipelines — Quiz

**1. Explain the concept of a stateful directed graph in agent pipelines. How does it differ from a simple linear pipeline?**
A stateful directed graph is a workflow where each step can store and use information from previous steps. The workflow is made up of nodes and edges that define how data moves through the system. It can support branching, looping, and decision-making, which makes it more flexible and intelligent. In contrast, a linear pipeline follows a fixed sequence of steps from start to finish without remembering previous states or changing its path.

**2. Describe the role of nodes and edges in an agent workflow. Give an example of each.**
Nodes are the individual tasks or actions performed in an agent workflow — they can represent operations such as processing a query, calling a tool, or generating a response. Edges are the connections between nodes that determine how information flows. For example, a "Calculator Tool" is a node, while the path connecting query analysis to the calculator is an edge. Together, nodes and edges define the complete workflow.

**3. What is conditional routing in an agent system? Design a simple rule-based routing logic for three different query types.**
Conditional routing is the process of directing a query to different tools or actions based on its intent, so the agent chooses the most appropriate response method. Example rule-based logic:
- If the query contains "calculate" or an arithmetic operator → route to the **Calculator Tool**.
- If the query contains "keyword" or "extract" → route to the **Keyword Extraction Tool**.
- Otherwise → route to a **General Response** module.

**4. Why are cycles (loops) important in agent pipelines? Provide a use case where a retry loop is necessary.**
Cycles or loops allow an agent to repeat a process until a desired result is achieved. They're useful when tasks may fail or need multiple attempts — for example, if an API request fails due to a temporary network issue, the agent can retry instead of immediately returning an error. This improves reliability and robustness; without loops, the workflow would stop after a single failure.

**5. Explain how a single-agent system can simulate multi-agent behavior internally.**
A single-agent system can simulate multiple agents by dividing its work into different roles — it may first analyze the query, then decide which tool to use, and finally generate a response. Each role behaves like a separate agent even though one system executes all of them. This reduces complexity while maintaining flexibility, letting a single agent perform tasks similar to a multi-agent architecture.

**6. What are JSON schema tools? How do they help in structuring tool inputs and outputs?**
JSON schema tools define a standard structure for data exchanged between agents and tools, specifying required fields, data types, and expected formats. This ensures inputs are valid before processing begins and makes outputs consistent and easier to interpret, reducing errors and improving communication between components.

**7. Compare sequential tool calls and parallel tool calls. When would you prefer one over the other?**
Sequential tool calls execute one after another, where each step depends on the previous result. Parallel tool calls execute multiple independent tasks at the same time. Sequential execution is preferred when tasks have dependencies; parallel execution is useful when tasks are unrelated and can run simultaneously — this can significantly reduce response time and improve efficiency.

**8. How would you implement error handling in a tool-using agent? Provide at least two strategies.**
Two common strategies: (1) using try/except blocks to catch exceptions and return meaningful error messages instead of crashing, and (2) implementing retry mechanisms that automatically repeat failed operations a limited number of times. Logging errors is also useful for debugging and monitoring, and together these techniques improve reliability and user experience.

**9. What is trajectory evaluation in agent systems? Why is it important beyond just checking final output?**
Trajectory evaluation examines the entire sequence of actions taken by an agent to solve a task — the decisions, tool calls, and intermediate steps — not just the final answer. This helps identify mistakes that may not be visible in the final output and is useful for debugging, optimization, and understanding agent behavior more deeply.

**10. Define task completion rate and cost metrics. How would you measure and optimize them in a real-world system?**
Task completion rate measures the percentage of tasks an agent completes successfully. Cost metrics represent the resources consumed — API calls, processing time, or money spent. Both can be measured by tracking agent performance across many runs. To optimize them, developers can improve routing accuracy, reduce unnecessary tool calls, and use more efficient algorithms — balancing high completion rates against low cost is key for real-world deployment.
